<?php

return [
    #'humhub_root' => '...',
    'modules' => ['birthday'],
    'fixtures' => ['default']
];



