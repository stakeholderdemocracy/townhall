<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Geburtstage</strong> in den nächsten {days} Tagen',
  'Back to modules' => 'Zurück zu den Modulen',
  'Birthday Module Configuration' => 'Konfiguration Geburtstagsmodul',
  'In {days} days' => 'In {days} Tagen',
  'Save' => 'Speichern',
  'The number of days future bithdays will be shown within.' => 'Anzahl an Tagen, an denen zukünftige Geburtstage vorab angezeigt werden.',
  'Tomorrow' => 'Morgen',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kannst die Anzahl an Tagen einstellen, an denen zukünftige Geburstage vorab angezeigt werden.',
  'becomes {years} years old.' => 'wird {years} Jahre alt.',
  'today' => 'heute',
);
