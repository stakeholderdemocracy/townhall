<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Sinh nhật</strong> Trong {days} hôm tới',
  'Back to modules' => 'Quay trở lại modules',
  'Birthday Module Configuration' => 'Cấu hình Module Birthday',
  'In {days} days' => 'Trong {days} ngày',
  'Save' => 'Lưu',
  'The number of days future bithdays will be shown within.' => 'Số ngày mà những ngày sinh nhật sắp tới sẽ được hiển thị',
  'Tomorrow' => 'Ngày mai',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Bạn có thể cấu hình khoảng ngày của các sinh nhật sắp tới.',
  'becomes {years} years old.' => 'Đã {years} tuổi.',
  'today' => 'hôm nay',
);
