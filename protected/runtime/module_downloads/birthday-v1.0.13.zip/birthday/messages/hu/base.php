<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '',
  'Back to modules' => '',
  'Birthday Module Configuration' => '',
  'In {days} days' => '',
  'Save' => 'Mentés',
  'The number of days future bithdays will be shown within.' => '',
  'Tomorrow' => '',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes {years} years old.' => '',
  'today' => '',
);
