<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Bursdager</strong> de kommende {days} dagene',
  'Back to modules' => 'Tilbake til moduler',
  'Birthday Module Configuration' => 'Konfigurér bursdag-modulen',
  'In {days} days' => 'Om {days} dager',
  'Save' => 'Lagre',
  'The number of days future bithdays will be shown within.' => 'Antall dager å vise burdager innenfor.',
  'Tomorrow' => 'I morgen',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kan konfigerere antall dager å vise bursdager innenfor.',
  'becomes {years} years old.' => 'blir {years} gammel.',
  'today' => 'i dag',
);
