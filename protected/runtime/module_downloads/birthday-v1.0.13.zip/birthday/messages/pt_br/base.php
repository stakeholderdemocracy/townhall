<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Aniversariantes</strong> durantes os próximos {days} dias.',
  'Back to modules' => 'Voltar aos módulos',
  'Birthday Module Configuration' => 'Configuração do Módulo de Aniversário',
  'In {days} days' => 'Em {days} dias.',
  'Save' => 'Salvar',
  'The number of days future bithdays will be shown within.' => 'O número de dias para exibição dos próximos aniversários no calendário.',
  'Tomorrow' => 'Amanhã',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Você pode configurar o número de dias antes dos próximos aniversários para que sejam mostrados no calendário.',
  'becomes {years} years old.' => 'completando {years} anos.',
  'today' => 'hoje',
);
