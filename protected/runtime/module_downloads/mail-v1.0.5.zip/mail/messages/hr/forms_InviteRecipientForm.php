<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Primatelj',
    'You cannot send a email to yourself!' => 'Ne možete poslati email sami sebi!',
];
