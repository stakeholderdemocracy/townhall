<?php
return array (
  'There are no messages yet.' => 'هنوز پیغامی وجود ندارد.',
);
