<?php

return [
    'Conversations' => '',
    'New' => 'جدید',
    'There are no messages yet.' => 'هنوز پیغامی وجود ندارد.',
];
