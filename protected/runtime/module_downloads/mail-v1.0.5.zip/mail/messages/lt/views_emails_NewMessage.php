<?php
return array (
  '<strong>New</strong> message' => '<strong>Nauja</strong> žinutė',
  'Reply now' => 'Atsakyti dabar',
  'sent you a new message:' => 'Jums atsiuntė naują žinutę:',
);
