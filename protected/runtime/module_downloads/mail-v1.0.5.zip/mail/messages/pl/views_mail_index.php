<?php

return [
    'Conversations' => '',
    'New' => 'Nowa ',
    'There are no messages yet.' => 'Nie ma jeszcze wiadomości. ',
];
