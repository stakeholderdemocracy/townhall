<?php
return array (
  'Recipient' => 'Címzett',
  'User {name} is already participating!' => '{name} már részt vesz.',
  'You are not allowed to send user {name} is already!' => 'Nem engedélyezett, hogy új beszélgetést kezdeményezz ( {name} ) , mert már van egy beszélgetésetek.',
  'You cannot send a email to yourself!' => 'Magadnak nem küldhetsz üzenetet!',
);
