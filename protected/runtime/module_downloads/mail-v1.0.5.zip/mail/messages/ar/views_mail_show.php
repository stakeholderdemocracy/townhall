<?php

return [
    'Delete conversation' => '',
    'Leave conversation' => '',
    '<strong>Confirm</strong> deleting conversation' => '<strong>تأكيد</strong> حذف المحادثة',
    '<strong>Confirm</strong> leaving conversation' => '<strong>تأكيد</strong> مغادرة المحادثة',
    '<strong>Confirm</strong> message deletion' => '<strong>تأكيد</strong> حذف الرسالة',
    'Add user' => 'اضافة مستخدم',
    'Cancel' => 'الغاء',
    'Delete' => 'حذف',
    'Do you really want to delete this conversation?' => 'هل تريد حذف هذه المحادثة؟',
    'Do you really want to delete this message?' => 'هل تريد حذف هذه الرسالة؟',
    'Do you really want to leave this conversation?' => 'هل تريد مغادرة هذه المحادثة؟',
    'Leave' => 'مغادرة',
    'Send' => 'ارسل',
    'There are no messages yet.' => 'لا توجد رسائل',
];
