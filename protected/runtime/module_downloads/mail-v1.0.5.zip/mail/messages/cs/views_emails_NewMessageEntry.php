<?php
return array (
  'sent you a new message in' => 'vám poslal novou zprávu v konverzaci',
);
