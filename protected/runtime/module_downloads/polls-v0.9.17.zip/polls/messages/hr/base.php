<?php
return array (
  'Allows to start polls.' => 'Dopusti pokretanje ankete',
  'Cancel' => 'Poništi',
  'Polls' => 'Ankete',
  'Save' => 'Spremi',
);
