<?php
return array (
  'Allows to start polls.' => 'Starten van stembussen toestaan.',
  'Cancel' => 'Annuleer',
  'Polls' => 'Stembus',
  'Save' => 'Bewaar',
);
