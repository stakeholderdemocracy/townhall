<?php
return array (
  'Allows to start polls.' => 'Permite iniciar encuestas.',
  'Cancel' => 'Cancelar',
  'Polls' => 'Votaciones',
  'Save' => 'Guardar',
);
