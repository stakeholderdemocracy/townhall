<?php
return array (
  'Again? ;Weary;' => 'Again? ;Weary;',
  'Club A Steakhouse' => 'Club A Steakhouse',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?',
  'To Daniel' => 'To Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Why don\'t we go to Bemelmans Bar?',
);
