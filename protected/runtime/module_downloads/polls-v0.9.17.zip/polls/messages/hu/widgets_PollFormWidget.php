<?php
return array (
  'Ask' => 'Mehet',
);
