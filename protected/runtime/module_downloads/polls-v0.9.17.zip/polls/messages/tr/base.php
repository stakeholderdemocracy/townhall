<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'İptal',
  'Polls' => 'Anketler',
  'Save' => 'Kaydet',
);
