<?php
return array (
  'Ask' => 'Chiedi',
);
