<?php
return array (
  'Allows to start polls.' => 'Consente di iniziare un sondaggio.',
  'Cancel' => 'Annulla',
  'Polls' => 'Sondaggi',
  'Save' => 'Salva',
);
