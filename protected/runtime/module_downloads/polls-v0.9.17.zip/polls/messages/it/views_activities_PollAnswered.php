<?php
return array (
  '{userName} answered the {question}.' => '{userName} ha risposto {question}.',
);
