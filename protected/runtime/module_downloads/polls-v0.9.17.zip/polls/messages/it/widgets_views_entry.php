<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Nota:</strong> I risultati sono nascosti fino alla chiusura da parte del moderatore. ',
  'Anonymous' => 'Anonimo',
  'Closed' => 'Chiuso',
  'Complete Poll' => 'Sondaggio completato',
  'Reopen Poll' => 'Sondaggio riaperto',
  'Reset my vote' => 'Resetta il mio voto',
  'Vote' => 'Vota',
  'and {count} more vote for this.' => 'più {count} voti per questo.',
  'votes' => 'voti',
);
