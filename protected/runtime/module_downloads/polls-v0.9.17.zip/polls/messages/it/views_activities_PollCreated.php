<?php
return array (
  '{userName} created a new {question}.' => '{userName} ha creato la nuova domanda {question}.',
);
