<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} criou uma nova enquete e atribuiu a você.',
);
