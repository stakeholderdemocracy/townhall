<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Отказ',
  'Polls' => 'Анкети',
  'Save' => 'Запази',
);
