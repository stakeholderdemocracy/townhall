<?php

return [
    'Allows to start polls.' => '',
    'Cancel' => '',
    'Polls' => '',
    'Save' => '',
];
