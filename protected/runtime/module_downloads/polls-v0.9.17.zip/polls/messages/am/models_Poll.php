<?php

return [
    'Answers' => '',
    'Multiple answers per user' => '',
    'Please specify at least {min} answers!' => '',
    'Question' => '',
];
