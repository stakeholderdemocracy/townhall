<?php
return array (
  'Allows to start polls.' => 'Tillåtelse att starta enkäter.',
  'Cancel' => 'Avbryt',
  'Polls' => 'Enkät',
  'Save' => 'Spara',
);
