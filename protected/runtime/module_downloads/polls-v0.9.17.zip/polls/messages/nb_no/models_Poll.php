<?php
return array (
  'Answers' => 'Svar',
  'Multiple answers per user' => 'Flere svar pr bruker',
  'Please specify at least {min} answers!' => 'Vennligst spesifisér minst {min} svaralternativer!',
  'Question' => 'Spørsmål',
);
