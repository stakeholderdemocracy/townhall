<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName}さんは新しいアンケートを作成して、あなたの回答を希望しています。',
);
