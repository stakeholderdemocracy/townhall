<?php
return array (
  'Answers' => 'Respuestas',
  'Multiple answers per user' => 'Multiples respuestas per usuario',
  'Please specify at least {min} answers!' => 'Per favor, especifica {min} respuestas como minimo!',
  'Question' => 'Pregunta',
);
