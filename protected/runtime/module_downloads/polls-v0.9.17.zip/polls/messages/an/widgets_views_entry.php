<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '',
  'Anonymous' => '',
  'Closed' => 'Zarrada',
  'Complete Poll' => 'Enqüesta completa',
  'Reopen Poll' => 'Reubrir a enqüesta',
  'Reset my vote' => '',
  'Vote' => 'Votar',
  'and {count} more vote for this.' => 'y {count} mas han votau per isto.',
  'votes' => 'votos',
);
