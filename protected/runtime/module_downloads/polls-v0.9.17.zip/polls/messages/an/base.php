<?php
return array (
  'Allows to start polls.' => 'Permitir iniciar enqüestas.',
  'Cancel' => 'Cancelar',
  'Polls' => 'Enqüestas',
  'Save' => 'Alzar',
);
