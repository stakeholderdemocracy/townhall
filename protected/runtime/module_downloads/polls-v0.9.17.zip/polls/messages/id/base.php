<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Batal',
  'Polls' => 'Pemungutan Suara',
  'Save' => 'Simpan',
);
