<?php
return array (
  'Allows to start polls.' => '',
  'Cancel' => 'Afbryd',
  'Polls' => 'Afstemninger',
  'Save' => 'Gem',
);
