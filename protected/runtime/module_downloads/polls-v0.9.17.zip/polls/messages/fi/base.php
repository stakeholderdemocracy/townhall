<?php
return array (
  'Allows to start polls.' => 'Antaa luoda kyselyitä',
  'Cancel' => 'Peruuta',
  'Polls' => 'Kyselyt',
  'Save' => 'Tallenna',
);
