<?php
return array (
  'Answers' => 'Vastausta',
  'Multiple answers per user' => 'Useita vastauksia',
  'Please specify at least {min} answers!' => 'Vastaa edes vähintään {min} kysymykseen!',
  'Question' => 'Kysymys',
);
