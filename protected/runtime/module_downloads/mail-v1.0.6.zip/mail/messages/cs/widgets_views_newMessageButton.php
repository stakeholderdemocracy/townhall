<?php
return array (
  'New message' => 'Nová zpráva',
  'Send message' => 'Poslat zprávu',
);
