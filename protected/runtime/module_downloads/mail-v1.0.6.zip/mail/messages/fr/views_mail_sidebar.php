<?php
return array (
  'Groups' => 'Groupes',
  'Members' => 'Membres',
  'Spaces' => 'Espaces',
  'User Posts' => 'Publications de l\'utilisateur',
);
