<?php
return array (
  'Messages' => 'Messages',
  'New message' => 'Nouveau message',
  'Show all messages' => 'Afficher tous les messages',
);
