<?php
return array (
  'Message' => 'Poruka',
);
