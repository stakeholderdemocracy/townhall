<?php

return [
    'Add more participants to your conversation...' => 'Dodajte još sudionika u vaš razgovor...',
];
