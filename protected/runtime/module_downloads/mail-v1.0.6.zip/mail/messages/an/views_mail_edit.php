<?php

return [
    'Edit message entry' => 'Editar o mensache',
];
