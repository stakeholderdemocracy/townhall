<?php

return [
    'Add recipients' => '',
    'New message' => '',
    'Send' => '',
];
