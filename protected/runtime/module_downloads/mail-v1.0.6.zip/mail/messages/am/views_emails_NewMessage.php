<?php

return [
    '<strong>New</strong> message' => '',
    'Reply now' => '',
    'sent you a new message:' => '',
];
