<?php

return [
    'Add more participants to your conversation...' => 'Lisää osallistujia keskusteluun...',
];
