<?php
return array (
  'sent you a new message in' => 'あなたに新しいメッセージを送信',
);
