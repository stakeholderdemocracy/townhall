<?php
return array (
  '<strong>New</strong> message' => 'پیغام <strong>جدید</strong>',
  'Reply now' => 'الان پاسخ دهید',
  'sent you a new message:' => 'به شما یک پیغام جدید فرستاد:',
);
