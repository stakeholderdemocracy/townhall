<?php
return array (
  'Groups' => 'Gruppen',
  'Members' => 'Mitglieder',
  'Spaces' => 'Spaces',
  'User Posts' => 'Benutzerbeiträge',
);
