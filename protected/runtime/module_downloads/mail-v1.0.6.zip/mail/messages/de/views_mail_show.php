<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => 'Löschen der Unterhaltung <strong>bestätigen</strong>',
  '<strong>Confirm</strong> leaving conversation' => 'Verlassen der Unterhaltung <strong>bestätigen</strong>',
  '<strong>Confirm</strong> message deletion' => 'Löschen der Nachricht <strong>bestätigen</strong>',
  'Add user' => 'Benutzer hinzufügen',
  'Cancel' => 'Abbrechen',
  'Delete' => 'Löschen',
  'Delete conversation' => 'Unterhaltung löschen',
  'Do you really want to delete this conversation?' => 'Willst du diese Unterhaltung wirklich löschen?',
  'Do you really want to delete this message?' => 'Willst du diese Nachricht wirklich löschen?',
  'Do you really want to leave this conversation?' => 'Willst du diese Unterhaltung wirklich verlassen?',
  'Leave' => 'Verlassen',
  'Leave conversation' => 'Unterhaltung verlassen',
  'Send' => 'Senden',
  'There are no messages yet.' => 'Derzeit keine Nachrichten vorhanden.',
);
