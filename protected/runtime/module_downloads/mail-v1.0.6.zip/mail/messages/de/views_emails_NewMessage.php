<?php
return array (
  '<strong>New</strong> message' => '<strong>Neue</strong> Nachricht',
  'Reply now' => 'Antworte jetzt',
  'sent you a new message:' => 'hat dir eine neue Nachricht geschickt:',
);
