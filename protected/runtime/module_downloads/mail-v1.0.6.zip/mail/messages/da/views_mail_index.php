<?php

return [
    'Conversations' => '',
    'New' => 'Ny',
    'There are no messages yet.' => 'Der er ingen beskeder endnu.',
];
