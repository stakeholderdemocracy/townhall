<?php
return array (
  'Messages' => 'Beskeder',
  'New message' => 'Ny besked',
  'Show all messages' => 'Vis alle beskeder',
);
