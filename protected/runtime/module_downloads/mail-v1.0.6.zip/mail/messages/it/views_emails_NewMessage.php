<?php
return array (
  '<strong>New</strong> message' => '<strong>Nuovo</strong> messaggio',
  'Reply now' => 'Rispondi ora',
  'sent you a new message:' => 'invia un nuovo messaggio:',
);
