<?php
return array (
  'Groups' => 'Csoportok',
  'Members' => 'Tagok',
  'Spaces' => 'Témakörök',
  'User Posts' => 'Felhasználó bejegyzések',
);
