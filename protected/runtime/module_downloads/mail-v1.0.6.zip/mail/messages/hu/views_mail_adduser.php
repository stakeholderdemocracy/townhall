<?php
return array (
  'Add more participants to your conversation...' => 'További címzettek hozzáadása...',
);
