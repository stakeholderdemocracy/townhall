<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => 'Beszélgetés <strong>törlésének</strong>  megerősítése',
  '<strong>Confirm</strong> leaving conversation' => 'Beszélgetés <strong>elhagyása</strong>',
  '<strong>Confirm</strong> message deletion' => 'Üzenet <strong>törlésének</strong> megerősítése',
  'Add user' => 'További címzettek',
  'Cancel' => 'Mégsem',
  'Delete' => 'Törlés',
  'Delete conversation' => 'Beszélgetés törlése',
  'Do you really want to delete this conversation?' => 'Biztos törlöd ezt a beszélgetést?',
  'Do you really want to delete this message?' => 'Biztos törlöd ezt az üzenetet?',
  'Do you really want to leave this conversation?' => 'Tényleg ki akarsz lépni ebből a beszélgetésből?',
  'Leave' => 'Elhagyás',
  'Leave conversation' => 'Beszélgetés elhagyása',
  'Send' => 'Küldés',
  'There are no messages yet.' => 'Még nincs üzenet.',
);
