<?php
return array (
  '<strong>New</strong> message' => '<strong>Jauna</strong> ziņa',
  'Reply now' => 'Atbildēt tagad',
  'sent you a new message:' => 'nosūtija tev jaunu ziņu:',
);
