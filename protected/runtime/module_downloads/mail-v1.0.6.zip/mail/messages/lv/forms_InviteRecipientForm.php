<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Saņēmējs',
    'You cannot send a email to yourself!' => 'Tu nevari nosūtīt ziņojumu sev pašam',
];
